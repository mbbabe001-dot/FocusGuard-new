package com.focusguard.app.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.focusguard.app.data.FocusRepository

class FocusNotificationListenerService : NotificationListenerService() {
    private lateinit var repo: FocusRepository
    override fun onCreate() { super.onCreate(); repo = FocusRepository(applicationContext) }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        val active = repo.notificationRules()
        val profileBlocks = repo.profileNotificationsBlocked()
        val shouldCancel = active.contains(n.packageName) || (profileBlocks && repo.blockedPackages().contains(n.packageName))
        if (shouldCancel) cancelNotification(n.key)
    }
}
