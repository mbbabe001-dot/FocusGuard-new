package com.focusguard.app

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.focusguard.app.data.*
import com.focusguard.app.service.FocusVpnService
import com.focusguard.app.ui.AppTheme
import com.focusguard.app.util.Permissions
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val vpnLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) startService(Intent(this, FocusVpnService::class.java).setAction(FocusVpnService.ACTION_START))
    }
    private val notificationLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri -> uri?.let { contentResolver.openOutputStream(it)?.use { out -> out.write(FocusRepository(applicationContext).exportJson().toByteArray()) } } }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { contentResolver.openInputStream(it)?.bufferedReader()?.use { reader -> BackupManager.restore(applicationContext, reader.readText()) } } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainViewModel = viewModel(factory = MainViewModel.factory(applicationContext))
            FocusGuardRoot(vm, this, vpnLauncher, notificationLauncher, exportLauncher, importLauncher)
        }
    }
}

class MainViewModel(val appContext: android.content.Context) : ViewModel() {
    val repo = FocusRepository(appContext)
    var screen by mutableStateOf(Screen.DASHBOARD)
        private set
    var refreshTick by mutableLongStateOf(0L)
        private set
    var dark by mutableStateOf(appContext.getSharedPreferences(FocusRepository.PREFS, 0).getBoolean(FocusRepository.KEY_DARK, false))
        private set
    var focusEnd by mutableLongStateOf(appContext.getSharedPreferences(FocusRepository.PREFS, 0).getLong(FocusRepository.KEY_FOCUS_END, 0L))
        private set

    fun go(s: Screen) { screen = s; refresh() }
    fun refresh() { refreshTick++ }
    fun setDark(v: Boolean) { dark = v; appContext.getSharedPreferences(FocusRepository.PREFS,0).edit().putBoolean(FocusRepository.KEY_DARK,v).apply() }
    fun setFocusEnd(v: Long) { focusEnd = v; appContext.getSharedPreferences(FocusRepository.PREFS,0).edit().putLong(FocusRepository.KEY_FOCUS_END,v).putBoolean(FocusRepository.KEY_FOCUS_ACTIVE,v>0).apply() }

    companion object {
        fun factory(context: android.content.Context) = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T = MainViewModel(context) as T
        }
    }
}

enum class Screen { DASHBOARD, APPS, TIMELINE, FOCUS, PROFILES, WEBSITES, SETTINGS, REPORTS }

@Composable
fun FocusGuardRoot(
    vm: MainViewModel,
    activity: MainActivity,
    vpnLauncher: androidx.activity.result.ActivityResultLauncher<Intent>,
    notificationLauncher: androidx.activity.result.ActivityResultLauncher<String>,
    exportLauncher: androidx.activity.result.ActivityResultLauncher<String>,
    importLauncher: androidx.activity.result.ActivityResultLauncher<Array<String>>
) {
    AppTheme(darkTheme = vm.dark) {
        Scaffold(
            bottomBar = { NavigationBar { NavItem(Screen.DASHBOARD, Icons.Default.Home, "Home", vm); NavItem(Screen.APPS, Icons.Default.Apps, "Apps", vm); NavItem(Screen.FOCUS, Icons.Default.Timer, "Focus", vm); NavItem(Screen.REPORTS, Icons.Default.BarChart, "Stats", vm); NavItem(Screen.SETTINGS, Icons.Default.Settings, "Settings", vm) } }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (vm.screen) {
                    Screen.DASHBOARD -> Dashboard(vm)
                    Screen.APPS -> AppsScreen(vm)
                    Screen.TIMELINE -> TimelineScreen(vm)
                    Screen.FOCUS -> FocusScreen(vm)
                    Screen.PROFILES -> ProfilesScreen(vm)
                    Screen.WEBSITES -> WebsitesScreen(vm, activity, vpnLauncher)
                    Screen.SETTINGS -> SettingsScreen(vm, activity, notificationLauncher, exportLauncher, importLauncher)
                    Screen.REPORTS -> ReportsScreen(vm)
                }
            }
        }
    }
}

@Composable private fun NavItem(screen: Screen, icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, vm: MainViewModel) {
    NavigationBarItem(selected = vm.screen == screen, onClick = { vm.go(screen) }, icon = { Icon(icon, null) }, label = { Text(label) })
}

@Composable private fun Dashboard(vm: MainViewModel) {
    val usage = remember(vm.refreshTick) { vm.repo.todaysUsage() }
    val total = usage.sumOf { it.millis }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("FocusGuard", style = MaterialTheme.typography.headlineMedium); Text("Your device, your rules.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("Today's screen time", style = MaterialTheme.typography.labelLarge); Text(formatDuration(total), style = MaterialTheme.typography.displaySmall); Text("${usage.size} apps used", color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
        item { PermissionCard(vm) }
        item { Text("Most used", style = MaterialTheme.typography.titleLarge) }
        items(usage.take(6)) { row -> UsageRowCard(row) }
        item { OutlinedButton({ vm.go(Screen.TIMELINE) }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Timeline, null); Spacer(Modifier.width(8.dp)); Text("Open timeline") } }
    }
}

@Composable private fun UsageRowCard(row: UsageRow) {
    ListItem(headlineContent = { Text(row.app.label) }, supportingContent = { Text(formatDuration(row.millis)) }, leadingContent = { Icon(Icons.Default.Android, null) })
    HorizontalDivider()
}

@Composable private fun PermissionCard(vm: MainViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val usage = Permissions.hasUsageAccess(context)
    val access = Permissions.hasAccessibility(context)
    val notif = Permissions.hasNotificationListener(context)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!usage) PermissionButton("Usage access", "Required for screen-time statistics", Icons.Default.QueryStats) { Permissions.openUsageAccess(context) }
        if (!access) PermissionButton("App blocking access", "Enable FocusGuard in Accessibility", Icons.Default.Block) { Permissions.openAccessibility(context) }
        if (!notif) PermissionButton("Notification access", "Optional: dismiss selected app notifications", Icons.Default.NotificationsOff) { Permissions.openNotificationListener(context) }
    }
}

@Composable private fun PermissionButton(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { action() }) { ListItem(headlineContent = { Text(title) }, supportingContent = { Text(subtitle) }, leadingContent = { Icon(icon, null) }, trailingContent = { Icon(Icons.Default.ChevronRight, null) }) }
}

@Composable private fun AppsScreen(vm: MainViewModel) {
    val profileId = vm.repo.activeProfileId()
    val blocked = vm.repo.blockedPackages(profileId)
    val limits = vm.repo.limits(profileId)
    val apps = remember(vm.refreshTick) { vm.repo.installedApps() }
    var q by remember { mutableStateOf("") }
    var limitPkg by remember { mutableStateOf<String?>(null) }
    var limitText by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) { Text("Apps", style = MaterialTheme.typography.headlineSmall, Modifier.weight(1f)); IconButton({ vm.go(Screen.PROFILES) }) { Icon(Icons.Default.Tune, null) } }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Search installed apps") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(apps.filter { it.label.contains(q, true) || it.packageName.contains(q, true) }) { app ->
                val checked = blocked.contains(app.packageName)
                val currentLimit = limits[app.packageName]
                ListItem(
                    headlineContent = { Text(app.label) },
                    supportingContent = { Text(if (currentLimit == null) "No daily limit" else "Daily limit: ${currentLimit} min") },
                    leadingContent = { Icon(Icons.Default.Android, null) },
                    trailingContent = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton({ limitPkg=app.packageName; limitText=currentLimit?.toString().orEmpty() }) { Text("Limit") }
                            Switch(checked, { vm.repo.setBlocked(profileId, app.packageName, it); vm.refresh() })
                        }
                    }
                )
                HorizontalDivider()
            }
        }
    }
    if (limitPkg != null) {
        val pkg = limitPkg!!
        val label = apps.firstOrNull { it.packageName == pkg }?.label ?: pkg
        AlertDialog(
            onDismissRequest={limitPkg=null},
            title={Text("Daily limit • $label")},
            text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){ Text("Enter minutes. Use 0 to remove the limit."); OutlinedTextField(limitText,{limitText=it.filter(Char::isDigit)},label={Text("Minutes")}) }},
            confirmButton={TextButton({ val m=limitText.toIntOrNull() ?: 0; if(m>0) vm.repo.setLimit(profileId,pkg,m); else vm.repo.setLimit(profileId,pkg,0); limitPkg=null; vm.refresh() }){Text("Save")}},
            dismissButton={TextButton({limitPkg=null}){Text("Cancel")}}
        )
    }
}

@Composable private fun TimelineScreen(vm: MainViewModel) {
    val items = remember(vm.refreshTick) {
        val start = System.currentTimeMillis() - 24 * 60 * 60 * 1000
        vm.repo.timeline(start, System.currentTimeMillis())
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("24-hour timeline", style = MaterialTheme.typography.headlineSmall); Text("Based on Android UsageStats events.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(items.take(100)) { item ->
            val mins = ((item.end - item.start) / 60000L).coerceAtLeast(1)
            ListItem(headlineContent = { Text(item.label) }, supportingContent = { Text("${mins} min • ${android.text.format.DateFormat.getTimeFormat(vm.repoContext()).format(java.util.Date(item.start))}") }, leadingContent = { Icon(Icons.Default.History, null) })
            HorizontalDivider()
        }
    }
}

private fun MainViewModel.repoContext(): android.content.Context = appContext

@Composable private fun FocusScreen(vm: MainViewModel) {
    var minutes by remember { mutableIntStateOf(25) }
    var running by remember { mutableStateOf(vm.focusEnd > System.currentTimeMillis()) }
    var remaining by remember { mutableLongStateOf((vm.focusEnd - System.currentTimeMillis()).coerceAtLeast(0)) }
    LaunchedEffect(running, vm.focusEnd) {
        while (running) {
            remaining = (vm.focusEnd - System.currentTimeMillis()).coerceAtLeast(0)
            if (remaining <= 0) { running = false; vm.setFocusEnd(0L); break }
            delay(1000)
        }
    }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Study / Focus Timer", style = MaterialTheme.typography.headlineSmall)
        Text(if (running) formatDuration(remaining) else "${minutes}:00", style = MaterialTheme.typography.displayLarge)
        if (!running) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(15,25,45,60).forEach { m -> FilterChip(selected = minutes == m, onClick = { minutes=m }, label = { Text("${m}m") }) } }
            Button({ val end = System.currentTimeMillis()+minutes*60_000L; vm.repo.startFocus(minutes, vm.repo.activeProfileId()); vm.appContext.scheduleFocusAlarm(end); vm.setFocusEnd(end); running=true }, Modifier.fillMaxWidth()) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Start focus") }
        } else {
            Button({ vm.setFocusEnd(0); vm.appContext.cancelFocusAlarm(); running=false }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Icon(Icons.Default.Stop, null); Spacer(Modifier.width(8.dp)); Text("End session") }
            OutlinedButton({ vm.appContext.getSharedPreferences(FocusRepository.PREFS,0).edit().putLong(FocusRepository.KEY_BREAK_END,System.currentTimeMillis()+5*60_000L).apply(); vm.refresh() }, Modifier.fillMaxWidth()) { Text("Take a 5-minute break") }
        }
        OutlinedButton({ vm.go(Screen.PROFILES) }, Modifier.fillMaxWidth()) { Text("Choose blocking profile") }
        Text("While focus is active, the selected profile's blocked apps are enforced.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable private fun ProfilesScreen(vm: MainViewModel) {
    var newName by remember { mutableStateOf("") }
    var startText by remember { mutableStateOf("06:00") }
    var endText by remember { mutableStateOf("11:00") }
    var pinDialog by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pinText by remember { mutableStateOf("") }
    val profiles = remember(vm.refreshTick) { vm.repo.profiles() }
    val activeId = vm.repo.activeProfileId()
    val schedules = remember(vm.refreshTick, activeId) { vm.repo.schedules(activeId) }
    fun guarded(action: () -> Unit) { if (vm.repo.lockModeEnabled()) { pinText=""; pinDialog=action } else action() }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Blocking profiles", style = MaterialTheme.typography.headlineSmall) }
        items(profiles) { p ->
            val active = activeId == p.id
            Card(Modifier.fillMaxWidth().clickable { guarded { vm.repo.setActiveProfile(p.id); vm.refresh() } }) { Column(Modifier.padding(16.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Text(p.name, style=MaterialTheme.typography.titleMedium, Modifier.weight(1f)); if(active) AssistChip(onClick={}, label={Text("Active")}) }; Spacer(Modifier.height(6.dp)); Text("Strict: ${p.strict} • Notifications: ${p.notificationBlocking} • Screen limit: ${p.screenLimitMinutes ?: "off"}") } }
        }
        item { OutlinedTextField(newName, { newName=it }, Modifier.fillMaxWidth(), label={Text("New profile name")}); Button({ if(newName.isNotBlank()){ guarded { vm.repo.createProfile(newName.trim()); newName=""; vm.refresh() } } }, Modifier.fillMaxWidth()) { Text("Create profile") } }
        item { Text("Active profile settings", style=MaterialTheme.typography.titleLarge) }
        item { Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) { Text("Strict mode", Modifier.weight(1f)); val current = vm.repo.isProfileStrict(activeId); Switch(current, { guarded { vm.repo.setProfileStrict(activeId,it); vm.refresh() } }) } }
        item { Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) { Text("Notification blocking", Modifier.weight(1f)); val current = vm.repo.profileNotificationsBlocked(activeId); Switch(current, { guarded { vm.repo.setProfileNotificationBlocking(activeId,it); vm.refresh() } }) } }
        var screenLimitText by remember(vm.refreshTick) { mutableStateOf(vm.repo.profileScreenLimit(activeId)?.toString().orEmpty()) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) { OutlinedTextField(screenLimitText,{screenLimitText=it.filter(Char::isDigit)},Modifier.weight(1f),label={Text("Total daily screen limit (min)")}); Button({ val m=screenLimitText.toIntOrNull(); guarded { vm.repo.setProfileScreenLimit(activeId,m); vm.refresh() } }){Text("Save")} } }
        item { Text("Recurring schedule", style=MaterialTheme.typography.titleLarge) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) { OutlinedTextField(startText,{startText=it},Modifier.weight(1f),label={Text("Start HH:mm")}); OutlinedTextField(endText,{endText=it},Modifier.weight(1f),label={Text("End HH:mm")}) } }
        item { Button({ val s=parseMinute(startText); val e=parseMinute(endText); if(s!=null && e!=null) { guarded { vm.repo.addSchedule(activeId,s,e,127); vm.refresh() } } },Modifier.fillMaxWidth()){Text("Add daily schedule") } }
        items(schedules) { sch -> ListItem(headlineContent={Text("${minuteText(sch.startMinute)} → ${minuteText(sch.endMinute)}")},supportingContent={Text("Every day")},trailingContent={IconButton({guarded{vm.repo.deleteSchedule(sch.id);vm.refresh()}}){Icon(Icons.Default.Delete,null)}});HorizontalDivider() }
        item { OutlinedButton({ vm.go(Screen.APPS) }, Modifier.fillMaxWidth()) { Text("Edit blocked apps for active profile") } }
    }
    if (pinDialog != null) {
        AlertDialog(onDismissRequest={pinDialog=null},title={Text("Unlock Lock Mode")},text={OutlinedTextField(pinText,{pinText=it.filter(Char::isDigit).take(8)},label={Text("PIN")})},confirmButton={TextButton({ if(vm.repo.checkLockPin(pinText)){ val action=pinDialog; pinDialog=null; action?.invoke() } }){Text("Unlock")}},dismissButton={TextButton({pinDialog=null}){Text("Cancel")}})
    }
}

private fun parseMinute(s: String): Int? { val p=s.trim().split(":"); if(p.size!=2) return null; val h=p[0].toIntOrNull() ?: return null; val m=p[1].toIntOrNull() ?: return null; return if(h in 0..23 && m in 0..59) h*60+m else null }
private fun minuteText(m: Int) = "%02d:%02d".format(m/60,m%60)

@Composable private fun WebsitesScreen(vm: MainViewModel, activity: MainActivity, vpnLauncher: androidx.activity.result.ActivityResultLauncher<Intent>) {
    var pattern by remember { mutableStateOf("") }
    var keywordMode by remember { mutableStateOf(false) }
    var startText by remember { mutableStateOf("08:00") }
    var endText by remember { mutableStateOf("22:00") }
    val rules = remember(vm.refreshTick) { vm.repo.websiteRules() }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { Text("Web control", style=MaterialTheme.typography.headlineSmall, Modifier.weight(1f)); IconButton({ val intent=VpnService.prepare(activity); if(intent==null) activity.startService(Intent(activity,FocusVpnService::class.java).setAction(FocusVpnService.ACTION_START)) else vpnLauncher.launch(intent) }) { Icon(Icons.Default.Shield, null) } }
        Text("Local DNS filtering. HTTPS content is not decrypted. DNS-over-HTTPS/QUIC can bypass simple DNS filtering and is called out in the project documentation.", color=MaterialTheme.colorScheme.onSurfaceVariant)
        Row(verticalAlignment=Alignment.CenterVertically){ Text("Treat entry as keyword",Modifier.weight(1f)); Switch(keywordMode,{keywordMode=it}) }
        OutlinedTextField(pattern,{pattern=it},Modifier.fillMaxWidth(),label={Text(if(keywordMode)"Keyword, e.g. reels" else "Domain, e.g. instagram.com")})
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) { Button({ if(pattern.isNotBlank()){ vm.repo.addWebsiteRule(pattern,keywordMode); pattern=""; vm.refresh() } },Modifier.weight(1f)){Text("Add rule")}; OutlinedButton({ activity.startService(Intent(activity,FocusVpnService::class.java).setAction(FocusVpnService.ACTION_STOP)) },Modifier.weight(1f)){Text("Stop filter")} }
        Text("Daily web-block schedule", style=MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) { OutlinedTextField(startText,{startText=it},Modifier.weight(1f),label={Text("Start")}); OutlinedTextField(endText,{endText=it},Modifier.weight(1f),label={Text("End")}) }
        Button({ val s=parseMinute(startText); val e=parseMinute(endText); if(s!=null&&e!=null){vm.repo.setWebSchedule(s,e);vm.refresh()} },Modifier.fillMaxWidth()){Text("Save web schedule")}
        LazyColumn { items(rules){ r -> ListItem(headlineContent={Text(r.hostPattern)},supportingContent={Text(if(r.keyword)"keyword filter" else "domain filter")},trailingContent={IconButton({vm.repo.deleteWebsiteRule(r.id);vm.refresh()}){Icon(Icons.Default.Delete,null)}});HorizontalDivider()} }
    }
}

@Composable private fun SettingsScreen(vm: MainViewModel, activity: MainActivity, notificationLauncher: androidx.activity.result.ActivityResultLauncher<String>, exportLauncher: androidx.activity.result.ActivityResultLauncher<String>, importLauncher: androidx.activity.result.ActivityResultLauncher<Array<String>>) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Settings", style=MaterialTheme.typography.headlineSmall)
        Row(verticalAlignment=Alignment.CenterVertically){Text("Dark mode",Modifier.weight(1f));Switch(vm.dark,{vm.setDark(it)})}
        Row(verticalAlignment=Alignment.CenterVertically){Text("Block Shorts/Reels",Modifier.weight(1f));Switch(vm.repo.shortVideoBlockingEnabled(),{vm.repo.setShortVideoBlocking(it);vm.refresh()})}
        ListItem(headlineContent={Text("Battery optimization")},supportingContent={Text(if(Permissions.isIgnoringBatteryOptimizations(context))"Ignored for FocusGuard" else "Recommended for reliable blocking")},trailingContent={if(!Permissions.isIgnoringBatteryOptimizations(context)) Button({Permissions.openBatteryOptimization(context)}){Text("Open")}})
        ListItem(headlineContent={Text("Notification permission")},supportingContent={Text(if(Permissions.canPostNotifications(context))"Allowed" else "Needed for FocusGuard's timer/status notifications")},trailingContent={if(!Permissions.canPostNotifications(context) && android.os.Build.VERSION.SDK_INT>=33) Button({notificationLauncher.launch("android.permission.POST_NOTIFICATIONS")}){Text("Allow")}})
        ListItem(headlineContent={Text("Website filter")},supportingContent={Text("Configure blocked domains")},trailingContent={TextButton({vm.go(Screen.WEBSITES)}){Text("Open")}})
        ListItem(headlineContent={Text("Profiles")},supportingContent={Text("Strict mode, schedules and screen limits")},trailingContent={TextButton({vm.go(Screen.PROFILES)}){Text("Open")}})
        var pin by remember { mutableStateOf("") }
        var showPin by remember { mutableStateOf(false) }
        Row(verticalAlignment=Alignment.CenterVertically){Text("Lock Mode",Modifier.weight(1f));Switch(vm.repo.lockModeEnabled(),{ if(it){ showPin=true } else if(vm.repo.lockModeEnabled()){ showPin=true } })}
        if(showPin) AlertDialog(onDismissRequest={showPin=false},title={Text(if(vm.repo.hasLockPin())"Enter PIN" else "Create Lock PIN")},text={OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},label={Text("PIN")})},confirmButton={TextButton({ if(vm.repo.hasLockPin()){ if(vm.repo.checkLockPin(pin)){ vm.repo.setLockMode(!vm.repo.lockModeEnabled()); showPin=false; pin="" } } else if(pin.length>=4){ vm.repo.setLockPin(pin); vm.repo.setLockMode(true); showPin=false; pin="" }; vm.refresh() }){Text(if(vm.repo.hasLockPin())"Unlock" else "Enable")}},dismissButton={TextButton({showPin=false}){Text("Cancel")}})
        Text("Backup & restore", style=MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) { OutlinedButton({ exportLauncher.launch("focusguard-backup.json") }, Modifier.weight(1f)) { Text("Export") }; OutlinedButton({ importLauncher.launch(arrayOf("application/json","text/plain")) }, Modifier.weight(1f)) { Text("Import") } }
        Text("Privacy", style=MaterialTheme.typography.titleLarge)
        Text("FocusGuard is designed to keep usage data local. Installed-app inventory, usage history and rules are stored on-device. The website VPN is local and does not upload browsing data.", color=MaterialTheme.colorScheme.onSurfaceVariant)
        Text("For Google Play, AccessibilityService, installed-app visibility and VpnService require policy declarations/disclosures when applicable.", color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=12.sp)
    }
}

@Composable private fun ReportsScreen(vm: MainViewModel) {
    val usage = remember(vm.refreshTick) { vm.repo.todaysUsage().take(8) }
    val max = usage.maxOfOrNull { it.millis }?.coerceAtLeast(1L) ?: 1L
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Statistics", style=MaterialTheme.typography.headlineSmall)
        Text("Today", style=MaterialTheme.typography.titleLarge)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)){ Canvas(Modifier.fillMaxWidth().height(180.dp)) { val barW=size.width/(usage.size.coerceAtLeast(1)*1.4f); usage.forEachIndexed{idx,row-> val h=size.height*(row.millis.toFloat()/max); drawRoundRect(topLeft=androidx.compose.ui.geometry.Offset(idx*barW*1.4f,size.height-h),size=androidx.compose.ui.geometry.Size(barW,h),cornerRadius=androidx.compose.ui.geometry.CornerRadius(10f,10f),style=androidx.compose.ui.graphics.drawscope.Fill, alpha=0.8f)} } } }
        itemsWithSeparators(usage){ row -> ListItem(headlineContent={Text(row.app.label)},trailingContent={Text(formatDuration(row.millis))});HorizontalDivider() }
        Text("Blocks today: ${vm.repo.blockedCountSince(startOfDay())}")
        Text("Time saved is calculated from completed blocks and is intentionally a conservative metric.", color=MaterialTheme.colorScheme.onSurfaceVariant, fontSize=12.sp)
    }
}

@Composable private fun <T> itemsWithSeparators(list: List<T>, content: @Composable (T) -> Unit) { Column { list.forEach(content) } }

private fun android.content.Context.scheduleFocusAlarm(at: Long) {
    val am = getSystemService(android.app.AlarmManager::class.java)
    val pi = android.app.PendingIntent.getBroadcast(this, 702, Intent(this, com.focusguard.app.service.FocusAlarmReceiver::class.java), android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
    am.setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
}
private fun android.content.Context.cancelFocusAlarm() {
    val am = getSystemService(android.app.AlarmManager::class.java)
    val pi = android.app.PendingIntent.getBroadcast(this, 702, Intent(this, com.focusguard.app.service.FocusAlarmReceiver::class.java), android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
    am.cancel(pi)
}

private fun startOfDay(): Long { val c=java.util.Calendar.getInstance(); c.set(java.util.Calendar.HOUR_OF_DAY,0); c.set(java.util.Calendar.MINUTE,0); c.set(java.util.Calendar.SECOND,0); c.set(java.util.Calendar.MILLISECOND,0); return c.timeInMillis }
private fun formatDuration(ms: Long): String { val sec=(ms/1000).coerceAtLeast(0); val h=sec/3600; val m=(sec%3600)/60; val s=sec%60; return when{h>0->"${h}h ${m}m";m>0->"${m}m ${s}s";else->"${s}s"} }
