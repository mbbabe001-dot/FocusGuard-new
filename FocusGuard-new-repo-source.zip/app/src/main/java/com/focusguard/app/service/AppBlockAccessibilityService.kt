package com.focusguard.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.focusguard.app.BlockActivity
import com.focusguard.app.data.FocusRepository

class AppBlockAccessibilityService : AccessibilityService() {
    private lateinit var repo: FocusRepository
    private var lastBlockedPkg: String? = null
    private var lastLaunch: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        repo = FocusRepository(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (!::repo.isInitialized) repo = FocusRepository(applicationContext)
        val pkg = e.packageName?.toString() ?: return
        if (pkg == applicationContext.packageName || pkg == "android") return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return

        val prefs = getSharedPreferences(FocusRepository.PREFS, 0)
        val unlockUntil = prefs.getLong(FocusRepository.KEY_UNLOCK_UNTIL_PREFIX + pkg, 0L)
        if (unlockUntil > System.currentTimeMillis()) return

        val activeProfile = repo.effectiveProfileId()
        val strict = repo.isProfileStrict(activeProfile)
        val focusActive = prefs.getBoolean(FocusRepository.KEY_FOCUS_ACTIVE, false) && prefs.getLong(FocusRepository.KEY_FOCUS_END, 0L) > System.currentTimeMillis()
        val blockedByProfile = repo.blockedPackages(activeProfile).contains(pkg)
        val limit = repo.limits(activeProfile)[pkg]
        val used = repo.todayMillis(pkg)
        val overLimit = limit != null && used >= limit * 60_000L
        val screenLimit = repo.profileScreenLimit(activeProfile)
        val total = repo.todaysUsage().sumOf { it.millis }
        val overScreen = screenLimit != null && total >= screenLimit * 60_000L
        val shortVideo = repo.shortVideoBlockingEnabled() && shortVideoVisible(pkg, e)
        val shouldBlock = blockedByProfile || overLimit || overScreen || (focusActive && blockedByProfile) || shortVideo

        if (repo.breakActive() && focusActive && !overScreen && !overLimit) return
        if (!shouldBlock) return
        if (lastBlockedPkg == pkg && System.currentTimeMillis() - lastLaunch < 800) return
        lastBlockedPkg = pkg
        lastLaunch = System.currentTimeMillis()
        repo.logBlock(pkg, when {
            overScreen -> "screen-limit"
            overLimit -> "app-limit"
            focusActive -> "focus"
            shortVideo -> "shorts-reels"
            else -> "profile"
        })
        val label = repo.installedApps().firstOrNull { it.packageName == pkg }?.label ?: pkg
        startActivity(Intent(this, BlockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(BlockActivity.EXTRA_PACKAGE, pkg)
            putExtra(BlockActivity.EXTRA_LABEL, label)
        })
    }

    private fun shortVideoVisible(pkg: String, event: AccessibilityEvent): Boolean {
        val supported = setOf("com.google.android.youtube", "com.instagram.android", "com.facebook.katana", "com.zhiliaoapp.musically")
        if (pkg !in supported) return false
        val text = buildString {
            event.text?.forEach { append(it).append(' ') }
            event.contentDescription?.let { append(it) }
        }.lowercase()
        return text.contains("shorts") || text.contains("reels") || text.contains("short video")
    }

    override fun onInterrupt() = Unit
}
