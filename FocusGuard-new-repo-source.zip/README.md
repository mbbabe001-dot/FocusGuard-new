# FocusGuard

A local-first Android focus/productivity app scaffold for app blocking, usage statistics, profiles, schedules, focus sessions, notification blocking, and local DNS website filtering.

## Current baseline

- Android API 36 / 36.1-compatible project
- Android Gradle Plugin 8.13.2
- Kotlin 2.3.21
- Jetpack Compose BOM 2026.09.00
- Min SDK 26 / target SDK 36
- Single-app module with SQLiteOpenHelper for durable local data and SharedPreferences for fast settings
- No analytics SDK and no remote backend

## Open it

Use a current stable Android Studio. The project is configured for JDK 17 and API 36.1-compatible tooling. Install Android SDK Platform 36.1 and Build Tools through SDK Manager, then open the `FocusGuard` folder.

The development container used to generate this project does not have a local Android SDK/Gradle installation, so a full APK/device build could not be executed here. The source and XML were statically checked; device-only permission flows still need testing in Android Studio.

## Required user grants during testing

1. Usage access — screen-time statistics and history.
2. Accessibility access — foreground app enforcement and Short/Reels detection.
3. Notification listener access — optional notification dismissal.
4. VPN consent — website/domain filtering.
5. Android 13+ notification permission — focus/bypass notifications.
6. Battery optimization exemption — recommended for reliable long-running enforcement, subject to OEM behavior.

## Important platform limits

- AccessibilityService use is sensitive and needs a clear in-app disclosure and Play Console declaration for a general-purpose app.
- QUERY_ALL_PACKAGES is a sensitive permission on Google Play; this project uses it because the product's core UI needs installed-app discovery, but the Play declaration must be completed and justified.
- VpnService requires Play Console disclosure/declaration and must fit an allowed core use case. This app uses it for local website filtering.
- Strict/Lock Mode can protect FocusGuard's own controls, but a normal personal app cannot make itself impossible to disable from Android system settings. Stronger device-wide tamper resistance requires device-management/device-owner approaches and a different product/deployment model.
- The website VPN is a deliberately small IPv4 UDP DNS filter. DNS-over-HTTPS, DNS-over-TLS, direct-IP connections, IPv6 and some QUIC/HTTP3 paths can bypass this simple filter and are explicitly not claimed as blocked.
- Short/Reels detection is based on Accessibility event text/content-description and known social-video package names; UI changes or localization can reduce detection quality.
- Android UsageStats history is system-retained for a limited period; the app does not assume indefinite event history.

## Source map

- `MainActivity.kt` — Compose UI, navigation, dashboard, apps, timeline, focus, profiles, web control, reports, settings.
- `data/AppDatabase.kt` — SQLite schema.
- `data/FocusRepository.kt` — usage queries, rules, profiles, schedules, backup serialization.
- `data/BackupManager.kt` — local JSON restore.
- `service/AppBlockAccessibilityService.kt` — foreground app enforcement, limits and Short/Reels detection.
- `service/FocusNotificationListenerService.kt` — notification cancellation.
- `service/FocusVpnService.kt` — local DNS filtering VPN.
- `service/FocusAlarmReceiver.kt` — focus-completion notification.
- `BlockActivity.kt` — custom blocking screen and temporary 5-minute unlock.
- `ui/Theme.kt` — Compose theme.

## Play release checklist

Before publishing, complete the required Play Console declarations for sensitive APIs/permissions, provide the required in-app prominent disclosures, complete Data safety/privacy-policy information, test battery/OEM behavior on real devices, and run a release build with R8 enabled.

## Automated APK build

The repository includes `.github/workflows/android-apk.yml`. After pushing the project to GitHub, run **Actions → Build FocusGuard APK** (or push to `main`/`master`). The workflow installs JDK/Gradle/Android SDK and publishes `app-debug.apk` as a downloadable Actions artifact.
